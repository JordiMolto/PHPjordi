<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Exercici 1.4</title>
</head>


<body>
    <?php

    echo contrasenyaSegura($psswd);
    echo insert(); 
    echo resultat($operacio, $x, $y);
    ?>
</body>

</html>