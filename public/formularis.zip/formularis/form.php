<!DOCTYPE html>
<html lang="en">

<head>
    <title>calculadora</title>
</head>

<body>
    Formulari enviat correctament!
    </form>
</body>

</html>